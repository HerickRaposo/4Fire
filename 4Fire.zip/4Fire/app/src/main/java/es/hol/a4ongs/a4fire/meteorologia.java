package es.hol.a4ongs.a4fire;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class meteorologia extends AppCompatActivity {

    private WebView mywebview;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meteorologia);

        mywebview = (WebView) findViewById(R.id.meteorologia_web);  //Iniciliza o webview
        WebSettings webSetings = mywebview.getSettings();
        webSetings.setJavaScriptEnabled(true); //inicializa o javascript

        mywebview.loadUrl("https://queimadas.dgi.inpe.br/queimadas/risco-de-fogo-meteorologia");
        mywebview.setWebViewClient(new WebViewClient());
    }
}
